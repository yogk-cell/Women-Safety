import React, { useState } from "react";

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Modal,
  Alert,
} from "react-native";

export default function ContactScreen({
  contacts,
  onAddContact,
  onDeleteContact,
}) {
  const [modalVisible, setModalVisible] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");

  const handleSave = () => {
    const cleanName = name.trim();
    const cleanPhone = phone.trim();

    if (!cleanName || !cleanPhone) {
      Alert.alert("Missing Details", "Please enter name and phone number.");
      return;
    }

    const digits = cleanPhone.replace(/\D/g, "");

    if (digits.length < 7 || digits.length > 15) {
      Alert.alert("Invalid Number", "Please enter a valid phone number.");
      return;
    }

    onAddContact({
      id: Date.now().toString(),
      name: cleanName,
      phone: cleanPhone,
    });

    setName("");
    setPhone("");
    setModalVisible(false);
  };

  const confirmDelete = (id) => {
    Alert.alert(
      "Delete Contact",
      "Are you sure you want to delete this contact?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => onDeleteContact(id),
        },
      ]
    );
  };

  const renderContact = ({ item }) => (
    <View style={styles.contactCard}>
      <View style={styles.avatar}>
        <Text style={styles.avatarText}>
          {item.name.charAt(0).toUpperCase()}
        </Text>
      </View>

      <View style={styles.contactInfo}>
        <Text style={styles.contactName}>{item.name}</Text>
        <Text style={styles.phone}>{item.phone}</Text>
      </View>

      <TouchableOpacity
        onPress={() => confirmDelete(item.id)}
        style={styles.deleteButton}
      >
        <Text style={styles.deleteText}>Delete</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Emergency Contacts</Text>

      <Text style={styles.subtitle}>
        Add trusted people who can help you during an emergency.
      </Text>

      <TouchableOpacity
        style={styles.addButton}
        onPress={() => setModalVisible(true)}
      >
        <Text style={styles.addButtonText}>+ Add New Contact</Text>
      </TouchableOpacity>

      <Text style={styles.sectionTitle}>
        Saved Contacts ({contacts.length})
      </Text>

      <FlatList
        data={contacts}
        keyExtractor={(item) => item.id}
        renderItem={renderContact}
        ListEmptyComponent={
          <Text style={styles.emptyText}>
            No contacts added yet.
          </Text>
        }
      />

      <Modal
        visible={modalVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalBackground}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Add Emergency Contact</Text>

            <TextInput
              style={styles.input}
              placeholder="Enter contact name"
              value={name}
              onChangeText={setName}
            />

            <TextInput
              style={styles.input}
              placeholder="Enter phone number"
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
            />

            <TouchableOpacity
              style={styles.saveButton}
              onPress={handleSave}
            >
              <Text style={styles.saveText}>Save Contact</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#F5F7FA",
  },

  title: {
    fontSize: 27,
    fontWeight: "bold",
    color: "#263238",
    marginTop: 20,
  },

  subtitle: {
    fontSize: 14,
    color: "#78909C",
    marginTop: 8,
    marginBottom: 25,
  },

  addButton: {
    backgroundColor: "#E53935",
    padding: 16,
    borderRadius: 14,
    alignItems: "center",
    marginBottom: 25,
  },

  addButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },

  sectionTitle: {
    fontSize: 19,
    fontWeight: "bold",
    color: "#263238",
    marginBottom: 15,
  },

  contactCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 14,
    borderRadius: 15,
    marginBottom: 12,
    elevation: 3,
  },

  avatar: {
    width: 45,
    height: 45,
    borderRadius: 25,
    backgroundColor: "#FFCDD2",
    justifyContent: "center",
    alignItems: "center",
  },

  avatarText: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#C62828",
  },

  contactInfo: {
    flex: 1,
    marginLeft: 12,
  },

  contactName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#263238",
  },

  phone: {
    fontSize: 14,
    color: "#78909C",
    marginTop: 4,
  },

  deleteButton: {
    padding: 8,
  },

  deleteText: {
    color: "#E53935",
    fontWeight: "bold",
  },

  emptyText: {
    textAlign: "center",
    color: "#90A4AE",
    marginTop: 35,
    fontSize: 15,
  },

  modalBackground: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    padding: 25,
  },

  modalBox: {
    backgroundColor: "#fff",
    padding: 25,
    borderRadius: 20,
  },

  modalTitle: {
    fontSize: 21,
    fontWeight: "bold",
    marginBottom: 20,
    color: "#263238",
  },

  input: {
    borderWidth: 1,
    borderColor: "#CFD8DC",
    borderRadius: 12,
    padding: 14,
    marginBottom: 15,
    fontSize: 16,
  },

  saveButton: {
    backgroundColor: "#E53935",
    padding: 15,
    borderRadius: 12,
    alignItems: "center",
  },

  saveText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },

  cancelText: {
    textAlign: "center",
    marginTop: 18,
    color: "#78909C",
    fontSize: 15,
  },
});