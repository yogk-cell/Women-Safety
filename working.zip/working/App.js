
import React, {
  useEffect,
  useState,
  useRef,
  useCallback,
} from "react";

import {
  View,
  Text,
  StyleSheet,
  Alert,
  TouchableOpacity,
  Switch,
  Animated,
  Easing,
  Linking,
} from "react-native";

import {
  SafeAreaProvider,
  SafeAreaView,
} from "react-native-safe-area-context";

import * as Location from "expo-location";
import { Accelerometer } from "expo-sensors";
import * as SMS from "expo-sms";
import { LinearGradient } from "expo-linear-gradient";
import AsyncStorage from "@react-native-async-storage/async-storage";

import ContactScreen from "./ContactScreen";
import UserScreen from "./UserScreen";

export default function App() {
  const [location, setLocation] = useState(null);
  const [address, setAddress] = useState("Fetching location...");
  const [shakeEnabled, setShakeEnabled] = useState(false);
  const [activeTab, setActiveTab] = useState("Home");
  const [contacts, setContacts] = useState([]);
  const [storageLoaded, setStorageLoaded] = useState(false);
  const [loadingLocation, setLoadingLocation] = useState(false);

  const scaleAnim = useRef(new Animated.Value(1)).current;
  const lastShakeTime = useRef(0);
  const locationLoadingRef = useRef(false);
  const sosInProgress = useRef(false);

  // ----------------------------------
  // LOAD SAVED CONTACTS
  // ----------------------------------

  useEffect(() => {
    const loadContacts = async () => {
      try {
        const savedContacts = await AsyncStorage.getItem(
          "emergencyContacts"
        );

        if (savedContacts) {
          const parsedContacts = JSON.parse(savedContacts);

          if (Array.isArray(parsedContacts)) {
            setContacts(parsedContacts);
          }
        }
      } catch (error) {
        console.log("Error loading contacts:", error);
      } finally {
        setStorageLoaded(true);
      }
    };

    loadContacts();
  }, []);

  // ----------------------------------
  // SAVE CONTACTS
  // ----------------------------------

  useEffect(() => {
    if (!storageLoaded) return;

    AsyncStorage.setItem(
      "emergencyContacts",
      JSON.stringify(contacts)
    ).catch(error =>
      console.log("Error saving contacts:", error)
    );
  }, [contacts, storageLoaded]);

  // ----------------------------------
  // ADD CONTACT
  // ----------------------------------

  const addContact = (contact) => {
    setContacts(previousContacts => [
      ...previousContacts,
      contact,
    ]);
  };

  // ----------------------------------
  // DELETE CONTACT
  // ----------------------------------

  const deleteContact = (id) => {
    setContacts(previousContacts =>
      previousContacts.filter(contact => contact.id !== id)
    );
  };

  // ----------------------------------
  // GET CURRENT GPS LOCATION
  // ----------------------------------

  const getCurrentLocation = useCallback(async () => {
    if (locationLoadingRef.current) {
      return null;
    }

    locationLoadingRef.current = true;
    setLoadingLocation(true);

    try {
      const { status } =
        await Location.requestForegroundPermissionsAsync();

      if (status !== "granted") {
        setAddress("Location permission denied");
        return null;
      }

      const currentLocation =
        await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.High,
        });

      const coords = currentLocation.coords;

      setLocation(coords);

      try {
        const result = await Location.reverseGeocodeAsync({
          latitude: coords.latitude,
          longitude: coords.longitude,
        });

        if (result.length > 0) {
          const place = result[0];

          setAddress(
            [
              place.name,
              place.street,
              place.city,
              place.region,
            ]
              .filter(Boolean)
              .join(", ")
          );
        } else {
          setAddress("Address not available");
        }
      } catch (error) {
        setAddress("Coordinates available, address unavailable");
      }

      return coords;

    } catch (error) {
      console.log("Location error:", error);
      setAddress("Unable to fetch location");
      return null;

    } finally {
      locationLoadingRef.current = false;
      setLoadingLocation(false);
    }
  }, []);

  // ----------------------------------
  // FETCH LOCATION WHEN APP STARTS
  // ----------------------------------

  useEffect(() => {
    getCurrentLocation();
  }, [getCurrentLocation]);

  // ----------------------------------
  // SOS FUNCTION
  // ----------------------------------

  const handleSOS = useCallback(async () => {

    if (sosInProgress.current) return;

    sosInProgress.current = true;

    try {

      // Check saved contacts
      if (!contacts || contacts.length === 0) {
        Alert.alert(
          "No Emergency Contacts",
          "Please add emergency contacts before activating SOS."
        );
        return;
      }

      // Get phone numbers
      const phoneNumbers = contacts
        .map(contact => contact.phone)
        .filter(phone =>
          typeof phone === "string" &&
          phone.trim().length > 0
        );

      if (phoneNumbers.length === 0) {
        Alert.alert(
          "Invalid Contacts",
          "No valid phone numbers found."
        );
        return;
      }

      // Check SMS availability
      const smsAvailable = await SMS.isAvailableAsync();

      if (!smsAvailable) {
        Alert.alert(
          "SMS Unavailable",
          "SMS is not available on this device."
        );
        return;
      }

      // Fetch latest GPS location
      const coords = await getCurrentLocation();

      if (!coords) {
        Alert.alert(
          "Location Unavailable",
          "Unable to fetch your current location. Please enable GPS and try again."
        );
        return;
      }

      // Generate Google Maps link
      const googleMapsLink =
        `https://www.google.com/maps?q=${coords.latitude},${coords.longitude}`;

      // Create emergency message
      const emergencyMessage =
        "🚨 EMERGENCY SOS ALERT 🚨\n\n" +
        "I need immediate help. This is an emergency!\n\n" +
        "My current location:\n" +
        `Latitude: ${coords.latitude}\n` +
        `Longitude: ${coords.longitude}\n\n` +
        "Track my location here:\n" +
        googleMapsLink +
        "\n\nPlease contact me immediately!";

      // Ask user before opening SMS composer
      Alert.alert(
        "🚨 SOS ACTIVATED",
        "Your current GPS location has been fetched.\n\n" +
        `Emergency contacts: ${phoneNumbers.length}\n\n` +
        "Your emergency message is ready to send.",
        [
          {
            text: "Cancel",
            style: "cancel",
            onPress: () => {
              sosInProgress.current = false;
            },
          },
          {
            text: "Send SOS SMS",
            onPress: async () => {
              try {
                const result = await SMS.sendSMSAsync(
                  phoneNumbers,
                  emergencyMessage
                );

                if (result.result === "sent") {
                  Alert.alert(
                    "SMS Action Completed",
                    "The SMS interface reported that the message was sent."
                  );
                } else if (result.result === "cancelled") {
                  Alert.alert(
                    "SMS Cancelled",
                    "The emergency SMS was cancelled."
                  );
                } else {
                  Alert.alert(
                    "SMS Status Unknown",
                    "The SMS result could not be confirmed."
                  );
                }

              } catch (error) {
                console.log("SMS error:", error);

                Alert.alert(
                  "SMS Error",
                  "Unable to open the SMS application."
                );

              } finally {
                sosInProgress.current = false;
              }
            },
          },
        ]
      );

    } catch (error) {
      console.log("SOS error:", error);

      Alert.alert(
        "SOS Error",
        "Something went wrong while activating SOS."
      );

      sosInProgress.current = false;
    }

  }, [contacts, getCurrentLocation]);

  // ----------------------------------
  // SOS PULSE ANIMATION
  // ----------------------------------

  useEffect(() => {
    const animation = Animated.loop(
      Animated.sequence([
        Animated.timing(scaleAnim, {
          toValue: 1.08,
          duration: 800,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),

        Animated.timing(scaleAnim, {
          toValue: 1,
          duration: 800,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    );

    animation.start();

    return () => animation.stop();
  }, [scaleAnim]);

  // ----------------------------------
  // SHAKE DETECTION
  // ----------------------------------

  useEffect(() => {
    if (!shakeEnabled) return;

    Accelerometer.setUpdateInterval(300);

    const subscription = Accelerometer.addListener(data => {

      const acceleration = Math.sqrt(
        data.x * data.x +
        data.y * data.y +
        data.z * data.z
      );

      const now = Date.now();

      if (
        acceleration > 2.2 &&
        now - lastShakeTime.current > 3000
      ) {
        lastShakeTime.current = now;

        Alert.alert(
          "Shake Detected",
          "Do you want to activate SOS?",
          [
            {
              text: "Cancel",
              style: "cancel",
            },
            {
              text: "Activate SOS",
              onPress: handleSOS,
            },
          ]
        );
      }
    });

    return () => subscription.remove();

  }, [shakeEnabled, handleSOS]);

  // ----------------------------------
  // HOME SCREEN
  // ----------------------------------

  const renderHomeScreen = () => (
    <View style={styles.container}>

      <Text style={styles.heading}>
        Women Safety
      </Text>

      <Text style={styles.subtitle}>
        Your safety, our priority
      </Text>

      {/* SOS BUTTON */}

      <View style={styles.sosContainer}>
        <Animated.View
          style={{
            transform: [{ scale: scaleAnim }],
          }}
        >
          <TouchableOpacity
            style={styles.sosButton}
            onPress={handleSOS}
            activeOpacity={0.8}
            disabled={sosInProgress.current}
          >
            <Text style={styles.sosText}>
              SOS
            </Text>

            <Text style={styles.sosSubText}>
              TAP FOR HELP
            </Text>
          </TouchableOpacity>
        </Animated.View>
      </View>

      {/* SHAKE DETECTION */}

      <View style={styles.shakeCard}>
        <View style={{ flex: 1 }}>
          <Text style={styles.cardTitle}>
            Shake to Activate SOS
          </Text>

          <Text style={styles.cardSubtitle}>
            Enable shake detection
          </Text>
        </View>

        <Switch
          value={shakeEnabled}
          onValueChange={setShakeEnabled}
          trackColor={{
            false: "#B0BEC5",
            true: "#EF9A9A",
          }}
          thumbColor={
            shakeEnabled ? "#E53935" : "#FFFFFF"
          }
        />
      </View>

      {/* LOCATION CARD */}

      <View style={styles.locationCard}>
        <Text style={styles.cardTitle}>
          📍 Current Location
        </Text>

        <Text style={styles.locationText}>
          {address}
        </Text>

        {location && (
          <Text style={styles.coordinates}>
            Latitude: {location.latitude.toFixed(5)}
            {"\n"}
            Longitude: {location.longitude.toFixed(5)}
          </Text>
        )}

        <TouchableOpacity
          style={styles.refreshButton}
          onPress={getCurrentLocation}
          disabled={loadingLocation}
        >
          <Text style={styles.refreshText}>
            {loadingLocation
              ? "Refreshing..."
              : "Refresh Location"}
          </Text>
        </TouchableOpacity>

        {location && (
          <TouchableOpacity
            style={styles.refreshButton}
            onPress={() =>
              Linking.openURL(
                `https://www.google.com/maps?q=${location.latitude},${location.longitude}`
              )
            }
          >
            <Text style={styles.refreshText}>
              Open in Google Maps
            </Text>
          </TouchableOpacity>
        )}
      </View>

    </View>
  );

  // ----------------------------------
  // MAIN APP
  // ----------------------------------

  return (
    <SafeAreaProvider>
      <LinearGradient
        colors={["#F5F7FA", "#ECEFF1"]}
        style={styles.background}
      >
        <SafeAreaView
          style={styles.safeArea}
          edges={["top", "bottom"]}
        >
          <View style={styles.screenContent}>

            {/* SCREEN CONTENT */}

            <View style={styles.contentArea}>
              {activeTab === "Home" ? (
                renderHomeScreen()
              ) : activeTab === "Contacts" ? (
                <ContactScreen
                  contacts={contacts}
                  onAddContact={addContact}
                  onDeleteContact={deleteContact}
                />
              ) : (
                <UserScreen />
              )}
            </View>

            {/* BOTTOM NAVIGATION */}

            <View style={styles.bottomBar}>

              <TouchableOpacity
                style={styles.navButton}
                onPress={() => setActiveTab("Home")}
              >
                <Text style={styles.navIcon}>🏠</Text>

                <Text
                  style={[
                    styles.navText,
                    activeTab === "Home" &&
                      styles.activeNavText,
                  ]}
                >
                  Home
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.navButton}
                onPress={() => setActiveTab("Contacts")}
              >
                <Text style={styles.navIcon}>📞</Text>

                <Text
                  style={[
                    styles.navText,
                    activeTab === "Contacts" &&
                      styles.activeNavText,
                  ]}
                >
                  Contacts
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.navButton}
                onPress={() => setActiveTab("User")}
              >
                <Text style={styles.navIcon}>👤</Text>

                <Text
                  style={[
                    styles.navText,
                    activeTab === "User" &&
                      styles.activeNavText,
                  ]}
                >
                  User
                </Text>
              </TouchableOpacity>

            </View>

          </View>
        </SafeAreaView>
      </LinearGradient>
    </SafeAreaProvider>
  );
}

// ----------------------------------
// STYLES
// ----------------------------------

const styles = StyleSheet.create({

  background: {
    flex: 1,
  },

  safeArea: {
    flex: 1,
    marginTop: 15,
    marginHorizontal: 8,
  },

  screenContent: {
    flex: 1,
    borderRadius: 22,
    overflow: "hidden",
    backgroundColor: "#F5F7FA",
    elevation: 5,
  },

  contentArea: {
    flex: 1,
    marginTop: 10,
    marginBottom: 8,
  },

  container: {
    flex: 1,
    padding: 22,
    paddingTop: 30,
  },

  heading: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#263238",
    textAlign: "center",
  },

  subtitle: {
    fontSize: 14,
    color: "#78909C",
    textAlign: "center",
    marginTop: 5,
  },

  sosContainer: {
    alignItems: "center",
    justifyContent: "center",
    marginVertical: 35,
  },

  sosButton: {
    width: 175,
    height: 175,
    borderRadius: 90,
    backgroundColor: "#E53935",
    justifyContent: "center",
    alignItems: "center",
    elevation: 10,
    borderWidth: 8,
    borderColor: "#FFCDD2",
  },

  sosText: {
    fontSize: 42,
    color: "#FFFFFF",
    fontWeight: "bold",
  },

  sosSubText: {
    fontSize: 12,
    color: "#FFFFFF",
    fontWeight: "600",
    marginTop: 5,
  },

  shakeCard: {
    backgroundColor: "#FFFFFF",
    padding: 18,
    borderRadius: 15,
    flexDirection: "row",
    alignItems: "center",
    elevation: 3,
    marginBottom: 18,
  },

  cardTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#263238",
  },

  cardSubtitle: {
    fontSize: 12,
    color: "#78909C",
    marginTop: 5,
  },

  locationCard: {
    backgroundColor: "#FFFFFF",
    padding: 18,
    borderRadius: 15,
    elevation: 3,
  },

  locationText: {
    fontSize: 14,
    color: "#546E7A",
    marginTop: 12,
    lineHeight: 21,
  },

  coordinates: {
    fontSize: 12,
    color: "#78909C",
    marginTop: 8,
    lineHeight: 20,
  },

  refreshButton: {
    backgroundColor: "#FFEBEE",
    padding: 10,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 15,
  },

  refreshText: {
    color: "#E53935",
    fontWeight: "bold",
  },

  bottomBar: {
    flexDirection: "row",
    backgroundColor: "#FFFFFF",
    height: 70,
    justifyContent: "space-around",
    alignItems: "center",
    borderTopWidth: 1,
    borderTopColor: "#ECEFF1",
    elevation: 10,
  },

  navButton: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },

  navIcon: {
    fontSize: 21,
  },

  navText: {
    fontSize: 12,
    marginTop: 4,
    color: "#78909C",
    fontWeight: "600",
  },

  activeNavText: {
    color: "#E53935",
    fontWeight: "bold",
  },

});
