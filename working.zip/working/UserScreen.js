import React, { useState } from "react";
import {
View,
Text,
StyleSheet,
TextInput,
TouchableOpacity,
Alert,
ScrollView,
} from "react-native";

export default function UserScreen() {
const [name, setName] = useState("Your Name");
const [phone, setPhone] = useState("");
const [email, setEmail] = useState("");
const [editing, setEditing] = useState(false);

const saveProfile = () => {
if (!name.trim()) {
Alert.alert("Error", "Please enter your name.");
return;
}


setEditing(false);
Alert.alert("Success", "Profile updated successfully!");


};

return ( <ScrollView style={styles.container}> <Text style={styles.heading}>My Profile</Text> <Text style={styles.subtitle}>Manage your personal information</Text>


  <View style={styles.profileCard}>
    <View style={styles.avatar}>
      <Text style={styles.avatarText}>
        {name.charAt(0).toUpperCase()}
      </Text>
    </View>

    <Text style={styles.profileName}>{name}</Text>
    <Text style={styles.profileLabel}>App User</Text>
  </View>

  <View style={styles.detailsCard}>
    <Text style={styles.sectionTitle}>Personal Information</Text>

    <Text style={styles.label}>Full Name</Text>
    <TextInput
      style={styles.input}
      value={name}
      onChangeText={setName}
      editable={editing}
      placeholder="Enter your name"
    />

    <Text style={styles.label}>Mobile Number</Text>
    <TextInput
      style={styles.input}
      value={phone}
      onChangeText={setPhone}
      editable={editing}
      placeholder="Enter mobile number"
      keyboardType="phone-pad"
    />

    <Text style={styles.label}>Email Address</Text>
    <TextInput
      style={styles.input}
      value={email}
      onChangeText={setEmail}
      editable={editing}
      placeholder="Enter email address"
      keyboardType="email-address"
      autoCapitalize="none"
    />

    {editing ? (
      <TouchableOpacity style={styles.button} onPress={saveProfile}>
        <Text style={styles.buttonText}>Save Profile</Text>
      </TouchableOpacity>
    ) : (
      <TouchableOpacity
        style={styles.button}
        onPress={() => setEditing(true)}
      >
        <Text style={styles.buttonText}>Edit Profile</Text>
      </TouchableOpacity>
    )}
  </View>

  <Text style={styles.footer}>Women Safety App</Text>
</ScrollView>


);
}

const styles = StyleSheet.create({
container: {
flex: 1,
padding: 20,
backgroundColor: "#F5F7FA",
},
heading: {
fontSize: 26,
fontWeight: "bold",
color: "#263238",
marginTop: 15,
},
subtitle: {
color: "#78909C",
marginTop: 5,
marginBottom: 25,
},
profileCard: {
backgroundColor: "#FFFFFF",
padding: 25,
borderRadius: 18,
alignItems: "center",
elevation: 3,
marginBottom: 20,
},
avatar: {
width: 85,
height: 85,
borderRadius: 45,
backgroundColor: "#E53935",
justifyContent: "center",
alignItems: "center",
marginBottom: 12,
},
avatarText: {
color: "#FFFFFF",
fontSize: 36,
fontWeight: "bold",
},
profileName: {
fontSize: 21,
fontWeight: "bold",
color: "#263238",
},
profileLabel: {
color: "#78909C",
marginTop: 5,
},
detailsCard: {
backgroundColor: "#FFFFFF",
padding: 20,
borderRadius: 18,
elevation: 3,
},
sectionTitle: {
fontSize: 18,
fontWeight: "bold",
marginBottom: 20,
color: "#263238",
},
label: {
fontSize: 14,
fontWeight: "600",
color: "#546E7A",
marginBottom: 7,
},
input: {
borderWidth: 1,
borderColor: "#CFD8DC",
borderRadius: 10,
padding: 12,
marginBottom: 18,
color: "#263238",
backgroundColor: "#FAFAFA",
},
button: {
backgroundColor: "#E53935",
padding: 15,
borderRadius: 12,
alignItems: "center",
marginTop: 5,
},
buttonText: {
color: "#FFFFFF",
fontSize: 16,
fontWeight: "bold",
},
footer: {
textAlign: "center",
color: "#90A4AE",
marginTop: 25,
marginBottom: 20,
},
});
